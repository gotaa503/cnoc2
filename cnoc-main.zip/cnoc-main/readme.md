**ЕСЛИ У ВАС НЕТУ ПРОКСИ СЕРВЕРА, ВОЗМОЖНО АККАУНТ КОТОРЫЙ ВЫ ХОТИТЕ СНОСИТЬ НЕ БУДЕТ СНОШЕН!**
Termux:
pkg install python3
pip install requests fake_useragent termcolor
